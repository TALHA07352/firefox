# Change Firefox background.
## With this script you can change the firefox background.

#### You need to :

* Clone repository.
* Execute the script `./script.sh`.
* Make sure you don't have any spaces on your image name.
 
* If the wallpaper didn't appear and you got a path error when executing the script
* try in firefox search about:support the in the profile directory open "Open Directory"
* copy the path and put it in the default path in the script and retry executing

#### Thanks you for using my script !
![Screenshot from 2023-05-28 20-58-29](https://github.com/AsteroidusTv/Firefox-background/assets/113026499/0cee4735-bad8-4b8e-888e-998af83814e5)
